package simulation;

/**
 * Class for the song object
 *
 * Song object will include the artist and title of the song
 * Accessors for both the artist and song title are available to use
 * There is a toString method to represent the song object
 * Song objects will be compared to each other using the equals
 * and compareTo method
 * The compareTo method will be used for the TreeSet from
 * DanceMarathon
 * A hash set and hash map will use the hashCode method
 *
 * file: Song.java
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public class Song implements Comparable<Song>{
    //singer
    private final String singer;
    private final String songTitle;
    //title of the song made by the artist

    /**
     * Initialization of a Song Object
     * @param artist: singer
     * @param title: songTitle
     */
    public Song(String artist, String title){
        this.singer = artist;
        this.songTitle = title;
    }

    /**
     * Getting the artist of the song object
     * @return song artist
     */
    public String getArtist(){
        return this.singer;
    }

    /**
     * Getting the song title of the song object
     * @return song title
     */
    public String getTitle(){
        return this.songTitle;
    }

    /**
     * String representation of the song object
     * @return song object string representation of its artist and song title
     */
    public String toString(){
        return "Artist: " + this.singer + ", Title: " + this.songTitle;
    }

    /**
     * Comparing 2 artist of 2 different objects from the same class
     * @param obj other song object
     * @return if both song objects are the same or not
     */
    @Override
    public boolean equals(Object obj) {
        Song song1 = (Song) obj;
        return (song1.getArtist().equals(this.singer))
                && (song1.getTitle().equals(this.songTitle));
    }

    /**
     * Getting the hashcode of the song title and artist
     * @return combined hashcode of the song object
     */
    public int hashCode(){
        return this.songTitle.hashCode() + this.singer.hashCode();
    }

    /**
     *
     * @param other song object that's being compared
     * @return comparison between the artists of 2 song objects
     */
    @Override
    public int compareTo(Song other){

        int res = this.singer.compareTo(other.singer);
        if(res == 0){
            res = songTitle.compareTo(other.songTitle);
        }return res;
    }
}
