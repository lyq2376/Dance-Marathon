package simulation;
import java.io.File;
import java.util.*;
import java.io.FileNotFoundException;

/**
 * The main program is run on the command line with a toy file:
 *
 * $ java DanceMarathon filename
 * 1. The songs are read into the file into a hashmap called jukebox
 * 2. A simulation will be run as the jukebox.
 *      Each part of the simulation ends if a duplicate song is played.
 * 3. The simulation time, total songs,
 *      average number of duplicates are printed.
 * 4. Statistics about the most played song
 *      and a list of songs by the most popular artist will be
 *      displayed
 *
 *
 * file: DanceMarathon.java
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public class DanceMarathon {
    /**name of the file being used*/
    private String filename;
    /**a java dictionary of a song along with the number of plays*/
    private HashMap<Song, Integer> jukebox;
    /**list of songs in the jukebox*/
    private List<Song> songs;
    /**random generator for the songs*/
    private Random rnd;
    /**how many simulations are there*/
    private static final int MAX_SIMULATION =100000;
     /**check if a song has already been played*/
    private HashSet<Song> checkSongs;
     /**total number of songs played*/
    private int totalSongs;
    /**Average number of duplicates*/
    private int[]Average;

    /**
     * Setting up the jukebox
     * @param filename name of the file being used
     * @throws FileNotFoundException finding file error
     */
    public DanceMarathon(String filename) throws FileNotFoundException {
        /**jukebox is turning on*/
        System.out.println("Loading the jukebox with song:");
        /**songs from the file will be put into jukebox*/
        System.out.println("\tReading songs from " + filename + " into jukebox...");
        /**initialization of the jukebox*/
        this.jukebox = new HashMap<>();
        /**putting songs into the jukebox*/
        try (Scanner in = new Scanner(new File(filename))) {
            while (in.hasNext()) {
                String[] tracks = in.nextLine().split("<SEP>");
                Song song = new Song(tracks[2], tracks[3]);
                this.jukebox.put(song, 0);
            }
        } catch (FileNotFoundException fnfe) {
            System.out.println("Usage: java DanceMarathon " + filename);
        }
        /**making a list of songs*/
        this.songs = new ArrayList<>(this.jukebox.keySet());
        /**jukebox is fully loaded with a certain amount of songs*/
        System.out.println("\tJukebox is loaded with " + this.jukebox.size() + " songs");
        /**Printing out the first song and title of the jukebox*/
        System.out.println("\tFirst song in jukebox: Artist: " + this.songs.get(0).toString());
        /**Printing out the last song and title of the jukebox*/
        System.out.println("\tLast song in jukebox: Artist: " + this.songs.get(this.songs.size() - 1).toString());
    }

    /**
     * Simulation of the jukebox
     * @rit.pre jukebox is loaded with sangs
     */
    public void simulation(){
        /**Simulation will start to run soon*/
        System.out.println("Running the simulation. The jukebox starts rockin'!");
        /**Starts to look for the first 5 songs being played**/
        System.out.println("\tPrinting first 5 songs played");
        /** Setting up random generator**/
        this.rnd = new Random();
        /**Setting the seed of the random generator**/
        this.rnd.setSeed(42);
        /**Int variable to count the first 5 songs**/
        int five = 0;
        /**Private int variable for total int songs**/
        this.totalSongs = 0;
        /**Initialization of average duplication array*/
        this.Average = new int [MAX_SIMULATION];
        /**Simulation is now starting**/
        /**Starts timing the simulation**/
        long start = System.currentTimeMillis();
        for(int i = 0; i< MAX_SIMULATION; i++) {
            /**Initialization of checkSongs*/
            this.checkSongs = new HashSet<>();
            /**checking for duplicates*/
            int duplicate = 0;
            while (true) {
                duplicate++;
                /**getting randomized song*/
                Song randomSong = this.songs.get(this.rnd.nextInt(songs.size()));
                /**Printing out the first 5 songs*/
                if(five<5){
                    System.out.println("\t\t"+randomSong.toString());
                    five++;
                }
                /**checkSongs to add songs if they are not in the hashset or else break*/
                if (this.checkSongs.contains(randomSong)) {
                    break;
                } else {
                    this.checkSongs.add(randomSong);
                    this.jukebox.replace(randomSong, jukebox.get(randomSong) + 1);

                }
            }
            this.Average[i] = duplicate;
        }
        /**Ending simulation time**/
        long end = System.currentTimeMillis();
        /**getting the amount of time it took for the simulation to run*/
        long simulationTime = end - start;
         /**Simulation time is divided by 1000 because it is in milliseconds*/
        System.out.println("\tSimulation took " + (simulationTime/1000) + " seconds/s to run");

    }

    /**
     * Displaying the statistics of the jukebox and simulation
     * @rit.pre the simulation must be successful
     */
    public void statistics(){
        /**Starting to calculate statistics*/
        System.out.println("Displaying simulation statistics:");
        /**How many simulations took place*/
        System.out.println("\tNumber of simulations run: " + MAX_SIMULATION);

        for(int t: jukebox.values()){
            totalSongs += t;
        }
        /**How many songs were played**/
        System.out.println("\tTotal number of songs played: " + this.totalSongs);
        /**Calculation to get the average number of duplicates per simulation*/
        int ave = 0;
        for(int i=0; i < MAX_SIMULATION; i++){
            ave+=Average[i];
        }
        System.out.println("\tAverage number of songs played per simulation to get duplicate: " + (ave/Average.length));
        /**Finding the most played song*/
        Song played = null;
        int most_played = 0;
        for (Song song: jukebox.keySet()){
            if(most_played < jukebox.get(song)){
                most_played = jukebox.get(song);
                played = song;
            }
        }
        assert played != null;
        System.out.println("\tMost played song: " +  "\"" + played.getTitle() +  "\"" + " by " + "\"" + played.getArtist()+ "\"");
        /**Getting the songs made by the artists of the most played song in alphabetical order*/
        System.out.println("All songs alphabetically by " + "\"" + played.getArtist() +  "\"");
        /**TreeSet popular will sort the songs internally using the compareTo method from the song class*/
        TreeSet<Song> popular = new TreeSet<>();
        for(Song song: jukebox.keySet()){
            if(played.getArtist().compareTo(song.getArtist())==0){
                popular.add(song);
            }
        }
        /**Printing out the title of the song along with the number of plays*/
        for(Song psong: popular){
            for(Song song: jukebox.keySet()){
                if(psong ==song){
                    System.out.println("\t\t" + "\"" + song.getTitle() + "\"" + " with " + jukebox.get(song)+ " plays");
                }
            }

        }

    }

    /**
     * Starts the dance marathon
     * @param args filename
     * @throws FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
        /**dance object used for the dance marathon*/
        DanceMarathon dance = new DanceMarathon(args[0]);
        /**Running the simulation for the dance marathon*/
        dance.simulation();
        /**Displaying the statistics of the simulation from the dance marathon*/
        dance.statistics();
    }

}